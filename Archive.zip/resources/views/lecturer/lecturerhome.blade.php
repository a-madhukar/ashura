@extends('lecturer') 


@section('content')
    <h1>Classes </h1> 
@stop