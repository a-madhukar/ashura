
    Dear $name, 
    
    You have been added to the system. Please use the following 
    credentials to log into the system. 
    
    Email: $email
    Password: $password
    
    Thanks,
    Ashura
    
    *This is an auto generated response please do reply. 
