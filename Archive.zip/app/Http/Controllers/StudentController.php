<?php namespace App\Http\Controllers;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use Request;
    use Auth;
    use App\User;
    use App\Student;
use App\Attendance;
	use DB;
	use App\Module;
	use App\Transaction;

class StudentController extends Controller {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
        if(Auth::check())
        {
             return view('student.studenthome');
        }
        
        return redirect('/');
	}
    
    public function viewAttendance()
    {
		if(Auth::check())
	   {
		   $modules = Module::lists('module_name');
		   
		   
		   return view('student.viewAttendance',compact('modules'));
	   }
		
		return redirect('/');
    }
	
	public function addTransaction()
	{
		if(Auth::check())
		{
			return view('student.addTransaction');
		}
		
		return redirect('/');
		
		
	}
	
	public function saveTransaction()
	{
		if(Auth::check())
		{
			$student = Student::where('email',Auth::user()->email)->get()->toArray();
			
			$student_id=$student[0]['id'];
			
			$input = Request::all();
			
			//dd($input['purpose']);
			
			Transaction::create(['student_id'=>$student_id,'purpose'=>$input['purpose'],'amount'=>$input['amount'],'cardholdername'=>$input['cardholdername'],'cardno'=>$input['cardno'],'cv'=>$input['cv'],'expirydate'=>$input['expirydate']]);
			
			return redirect('student/home');
		}
		return redirect('/');
	}
	
	public function viewTransaction()
	{
		if(Auth::check())
		{
			$student= Student::where('email',Auth::user()->email)->get()->toArray();
			
			$student_id=$student[0]['id'];
			
			$transactions= Transaction::where('student_id',$student_id)->get()->toArray();
			
			//dd($transaction);
			
			return view('student.viewTransaction',compact('transactions'));
		}
		return redirect('/');
	}

	

}
